import json
from datetime import datetime

class FitnessTracker:
    def __init__(self):
        self.activity_logs = self.load_activity_logs()

    def load_activity_logs(self):
        try:
            with open('activity_logs.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return []

    def log_activity(self, steps, calories):
        entry = {
            'timestamp': datetime.now().isoformat(),
            'steps': steps,
            'calories': calories
        }
        self.activity_logs.append(entry)
        self.save_activity_logs()

    def save_activity_logs(self):
        with open('activity_logs.json', 'w') as f:
            json.dump(self.activity_logs, f)
