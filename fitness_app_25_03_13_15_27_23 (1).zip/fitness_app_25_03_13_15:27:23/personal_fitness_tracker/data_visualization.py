import matplotlib.pyplot as plt
from fitness_tracker import FitnessTracker

class DataVisualizer:
    def __init__(self, fitness_tracker):
        self.fitness_tracker = fitness_tracker

    def visualize_data(self):
        steps = [entry['steps'] for entry in self.fitness_tracker.activity_logs]
        calories = [entry['calories'] for entry in self.fitness_tracker.activity_logs]
        timestamps = [entry['timestamp'] for entry in self.fitness_tracker.activity_logs]

        plt.figure(figsize=(10, 5))
        plt.plot(timestamps, steps, label='Steps', marker='o')
        plt.plot(timestamps, calories, label='Calories Burned', marker='x')
        plt.xlabel('Date')
        plt.xticks(rotation=45)
        plt.ylabel('Count')
        plt.title('Fitness Progress Over Time')
        plt.legend()
        plt.tight_layout()
        plt.show()
