from datetime import datetime

def validate_input(value):
    try:
        return int(value)
    except ValueError:
        return None

def current_timestamp():
    return datetime.now().isoformat()
