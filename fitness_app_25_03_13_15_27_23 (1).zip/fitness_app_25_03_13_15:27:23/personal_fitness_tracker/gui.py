import tkinter as tk
from tkinter import messagebox
from fitness_tracker import FitnessTracker
from data_visualization import DataVisualizer

class FitnessTrackerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Personal Fitness Tracker")
        self.fitness_tracker = FitnessTracker()
        self.data_visualizer = DataVisualizer(self.fitness_tracker)
        self.create_widgets()

    def create_widgets(self):
        self.label = tk.Label(self.master, text="Fitness Tracker", font=("Helvetica", 16))
        self.label.pack()

        self.steps_label = tk.Label(self.master, text="Steps:")
        self.steps_label.pack()
        self.steps_entry = tk.Entry(self.master)
        self.steps_entry.pack()

        self.calories_label = tk.Label(self.master, text="Calories Burned:")
        self.calories_label.pack()
        self.calories_entry = tk.Entry(self.master)
        self.calories_entry.pack()

        self.log_button = tk.Button(self.master, text="Log Activity", command=self.log_activity)
        self.log_button.pack()

        self.visualize_button = tk.Button(self.master, text="View Progress", command=self.visualize_progress)
        self.visualize_button.pack()

    def log_activity(self):
        try:
            steps = int(self.steps_entry.get())
            calories = int(self.calories_entry.get())
            self.fitness_tracker.log_activity(steps, calories)
            messagebox.showinfo("Success", "Activity logged successfully!")
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for steps and calories.")

    def visualize_progress(self):
        self.data_visualizer.visualize_data()
